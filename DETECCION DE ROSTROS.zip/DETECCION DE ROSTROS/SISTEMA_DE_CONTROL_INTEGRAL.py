from tkinter import*
from tkinter import messagebox
from tkinter import ttk
#COMANDOS DE MENU______________________________________________________________
def MOD_BIOMETRICO():
	def PUERTO():
		import serial
		import serial.tools.list_ports

		ports=list(serial.tools.list_ports.comports())
		for puertos in ports:
			print(puertos)
		raiz2=Tk()
		barraMenu2=Menu(raiz2)
		raiz2.config(menu=barraMenu2)
		raiz2.title("PUERTOS DISPONIBLES Y ACTIVOS")
		raiz2.resizable(False,False)
		raiz2.geometry("600x150")

		LabelPuertos=Label(raiz2,text="PUERTOS DISPONIBLES:")
		LabelPuertos.config(bg="White")
		LabelPuertos.grid(row=0, column=0, sticky="w", padx=10, pady=10)

		puertosCom=Text(raiz2)
		puertosCom.insert(INSERT, ports)
		puertosCom.grid(row=1, column=0, padx=10, pady=10)
		raiz2.mainloop()		

	raiz=Tk()
	Tools=Menu(raiz)
	raiz.config(menu=Tools)
	raiz.title("SISTEMA DE ADMINISTRACION Y CONTROL DE SEGURIDAD")
	raiz.resizable(0,0)
	raiz.config(bg="White")
	raiz.geometry("720x200")



	# MENUS________________________________________________________________________________
	menuTools=Menu(Tools, tearoff=0)
	menuTools.config(bg="#7CB342")
	Tools.add_cascade(labe="Tools",menu=menuTools)
	menuTools.add_command(label="Ports", command=PUERTO)
	#menuTools.add_separator()
	'''miFrame=Frame()
	miFrame.pack(fill="both",expand="True")
	miFrame.config(bg="White")
	miFrame.config(width="500",height="400")'''
	#VARIABLES______________________________________________________________________________________
	baseAdmi=StringVar()
	basePass=StringVar()
	Usuario=StringVar()

	# ETIQUETAS_________________________________________________________________________________________
	LabelNombre=Label(raiz,text="NOMBRE DEL ADMINISTRADOR:")
	LabelNombre.config(bg='White')
	LabelNombre.grid(row=0, column=0, sticky="w", padx=10, pady=10)

	LabelPass=Label(raiz,text="PASSWORD:")
	LabelPass.config(bg="White")
	LabelPass.grid(row=1, column=0, sticky="w", padx=10, pady=10)

	LabelUsuario=Label(raiz,text="NUEVO USUARIO:")
	LabelUsuario.config(bg="White")
	LabelUsuario.grid(row=2, column=0, sticky="w", padx=10, pady=10)

	LabelSerial=Label(raiz,text="PUERTO SERIAL SELECCIONADO:")
	LabelSerial.config(bg="White")
	LabelSerial.grid(row=0, column=2, sticky="w", padx=10, pady=10)
	LabelCamara=Label(raiz,text="CAMARA SELECCIONADA:")
	LabelCamara.config(bg="White")
	LabelCamara.grid(row=1, column=2, sticky="w", padx=10, pady=10)
	# CUADROS DE TEXTOS_________________________________________________________________________________
	cuadroNombreAdmi=Entry(raiz,textvariable=baseAdmi)
	cuadroNombreAdmi.grid(row=0, column=1, sticky="w")
	baseAdmi.set("")

	cuadroPass=Entry(raiz,textvariable=basePass)
	cuadroPass.grid(row=1, column=1, sticky="w")
	cuadroPass.config(show="*")
	basePass.set("")

	cuadroNuevoUsuario=Entry(raiz,textvariable=Usuario)
	cuadroNuevoUsuario.grid(row=2, column=1, sticky="w")
	Usuario.set("")

	cuadroSerial=ttk.Combobox(raiz, values=["COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9"],state="readonly")
	cuadroSerial.grid(row=0, column=3, sticky="w")
	cuadroCamara=ttk.Combobox(raiz, values=["0","1","2","3","4","5","6","7","8","9","10"],state="readonly")
	cuadroCamara.grid(row=1, column=3, sticky="w")
	#_______________________________________________________________
	# Mensajes 1-4
	def mensaje1():
		messagebox.showinfo("MENSAJE","PASSWORD INCORRECTO")
	def mensaje2():
		messagebox.showinfo("MENSAJE","USUARIO INCORRECTO")
	def mensaje3():
		messagebox.showinfo("MENSAJE","Entrenando...")
	def mensaje4():
		messagebox.showinfo("ESTATUS","Modelo almacenado...")
	def mensaje5():
		messagebox.showinfo("CAMARA","BUSCANDO CAMARA.....")	
	def mensaje6():
		messagebox.showinfo("CAMARA","CAMARA NO ENCONTRADA")
	#_______________________________________________________________
	# FUNCIONES
	def RECONOCIMIENTO():
		import cv2
		import os
		import serial
		import time

		selecCamara=cuadroCamara.get()
		lecCam = int(selecCamara)

		if lecCam >= 0:
			mensaje5()
		dataPath = r'C:\Users\Ingen\Desktop\DETECCION DE ROSTROS\Data'
		imagePaths = os.listdir(dataPath)
		print('imagePaths=',imagePaths)
		face_recognizer = cv2.face.LBPHFaceRecognizer_create()
		face_recognizer.read('modeloLBPHFace.xml')
		cap = cv2.VideoCapture(lecCam,cv2.CAP_DSHOW)
		faceClassif = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')

		while True:
			ret,frame = cap.read()
			if ret == False:
				break
			gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
			auxFrame = gray.copy()
			faces = faceClassif.detectMultiScale(gray,1.3,5)

			for (x,y,w,h) in faces:
				rostro = auxFrame[y:y+h,x:x+w]
				rostro = cv2.resize(rostro,(150,150),interpolation= cv2.INTER_CUBIC)
				result = face_recognizer.predict(rostro)
				cv2.putText(frame,'{}'.format(result),(x,y-5),1,1.3,(255,255,0),1,cv2.LINE_AA)
				# LBPHFace

				if result[1] < 70:
					cv2.putText(frame,'{}'.format(imagePaths[result[0]]),(x,y-25),2,1.1,(0,255,0),1,cv2.LINE_AA)
					cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),2)
					cv2.putText(frame,'Acceso concedido',(x,y+210),2,0.8,(0,255,0),1,cv2.LINE_AA)
					break
				else:
					cv2.putText(frame,'Desconocido',(x,y-20),2,0.8,(0,0,255),1,cv2.LINE_AA)
					cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),2)
					cv2.putText(frame,'Acceso denegado',(x,y+210),2,0.8,(0,0,255),1,cv2.LINE_AA)

			cv2.imshow('Camara', frame)
			k = cv2.waitKey(1)
			if k == 27:
				break
		cap.release()
		cv2.destroyAllWindows()
	botonBDD=Button(raiz,text="RECONCIMEINTO BIOMETRICO",command=RECONOCIMIENTO)
	botonBDD.config(bg="#329b93")
	botonBDD.grid(row=3, column=0, padx=10, pady=10)
	#botonBDD.pack()

	def CAPTURAR():
		nameAdmin=baseAdmi.get()
		password=basePass.get()

		if password == 'ingeniero3991':
			if nameAdmin =='Yetlanezi Reynoso Carreon':
				import cv2
				import os
				import imutils
				camaraActiva=int(cuadroCamara.get())
				name=Usuario.get()
				personName = name
				dataPath = r'C:\Users\Ingen\Desktop\DETECCION DE ROSTROS\Data'
				personPath = dataPath + '/' + personName
				if not os.path.exists(personPath):
					print('Carpeta creada: ',personPath)
					os.makedirs(personPath)
				cap = cv2.VideoCapture(camaraActiva,cv2.CAP_DSHOW)
				#cap = cv2.VideoCapture('Video.mp4')
				faceClassif = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
				count = 0

				while True:
					ret, frame = cap.read()
					if ret == False: 
						break

					frame =  imutils.resize(frame, width=640)
					gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
					auxFrame = frame.copy()
					faces = faceClassif.detectMultiScale(gray,1.3,5)

					for (x,y,w,h) in faces:
						cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),2)
						rostro = auxFrame[y:y+h,x:x+w]
						rostro = cv2.resize(rostro,(150,150),interpolation=cv2.INTER_CUBIC)
						cv2.imwrite(personPath + '/rostro_{}.jpg'.format(count),rostro)
						count = count + 1
					cv2.imshow('frame',frame)
					k =  cv2.waitKey(1)
					if k == 27 or count >= 300:
						break

				cap.release()
				cv2.destroyAllWindows()
			else:
				mensaje2()
		else:
			mensaje1()
	botonCapturar=Button(raiz,text="CAPTURAR ROSTROS",command=CAPTURAR)
	botonCapturar.config(bg="#329b93")
	botonCapturar.grid(row=3, column=1, padx=10, pady=10)
	#botonCapturar.pack()

	def ENTRENAR_SISTEMA():
		nameAdmin=baseAdmi.get()
		password=basePass.get()

		if password == 'ingeniero3991':
			if nameAdmin =='Yetlanezi Reynoso Carreon':
				import cv2
				import os
				import numpy as np

				dataPath = r'C:\Users\Ingen\Desktop\DETECCION DE ROSTROS\Data'
				peopleList = os.listdir(dataPath)
				print('Lista de personas: ', peopleList)
				labels = []
				facesData = []
				label = 0

				for nameDir in peopleList:
					personPath = dataPath + '/' + nameDir
					print('Leyendo las imágenes')

					for fileName in os.listdir(personPath):
						print('Rostros: ', nameDir + '/' + fileName)
						labels.append(label)
						facesData.append(cv2.imread(personPath+'/'+fileName,0))
					label = label + 1

				face_recognizer = cv2.face.LBPHFaceRecognizer_create()
				mensaje3()
				print("Entrenando...")
				face_recognizer.train(facesData, np.array(labels))
				face_recognizer.write('modeloLBPHFace.xml')
				mensaje4()
				print("Modelo almacenado...")
			else:
				mensaje2()
		else:
			mensaje1()
	botonEntrenar=Button(raiz,text="ENTRENAR SISTEMA",command=ENTRENAR_SISTEMA)
	botonEntrenar.config(bg="#329b93")
	botonEntrenar.grid(row=3, column=2, padx=10, pady=10)
	#botonCapturar.pack()

	def SALIDA():
		import serial

		salidaPuerto=cuadroSerial.get()
		serialArduino = serial.Serial(salidaPuerto,9600)

		led=0
		opciones=input()
		if opciones=='L':
			led=1
			cad = str(led)
			serialArduino.write(cad.encode('ascii'))   
	botonSalidas=Button(raiz,text="SALIDAS DE SISTEMA",command=SALIDA)
	botonSalidas.config(bg="#329b93")
	botonSalidas.grid(row=3, column=3, padx=10, pady=10)
	#botonCapturar.pack()
	raiz.mainloop()

# MENU HOME____________________________________________________________________
raizHome=Tk()
ToolsHome=Menu(raizHome)
raizHome.config(menu=ToolsHome)

raizHome.title("SISTEMA DE ADMINISTRACION Y CONTROL DE SEGURIDAD")
raizHome.resizable(1,1)
raizHome.config(bg="White")
raizHome.geometry("720x200")

# MENUS________________________________________________________________________________
menuToolsHome=Menu(ToolsHome, tearoff=0)
menuToolsHome.config(bg="#7CB342")
ToolsHome.add_cascade(labe="Tools",menu=menuToolsHome)
menuToolsHome.add_command(label="Ports")

#VARIABLES______________________________________________________________________________________
Biometrico=StringVar()


#ETIQUETAS_____________________________________________________
LabelBiometrico=Label(raizHome,text="REGISTROS BOMETRICOS:")
LabelBiometrico.config(bg="White")
LabelBiometrico.grid(row=0, column=0, sticky="w", padx=10, pady=10)
#CUADROS DE TEXTO___________________________________________________
cuadroBiometrico=Entry(raizHome,textvariable=Biometrico)
cuadroBiometrico.grid(row=0, column=1, sticky="w")
Biometrico.set("")


botonBiometrico=Button(raizHome,text="Biometrico",command=MOD_BIOMETRICO)
botonBiometrico.config(bg="#329b93")
botonBiometrico.grid(row=1, column=1, padx=10, pady=10)
#botonCapturar.pack()



raizHome.mainloop()


